package org.ssis.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hellospring4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
